# Corporate Custom Colors

This plugin adds custom colors functionality into the Corporate WordPress Theme. See the Creative Market [1] product page for more information.

[1] https://creativemarket.com/professionalthemes/382762-Corporate-WordPress-Theme  
